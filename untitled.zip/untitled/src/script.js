// JavaScript File: script.js
document.addEventListener("DOMContentLoaded", function() {
    const ctaButtons = document.querySelectorAll(".cta");
    ctaButtons.forEach(button => {
        button.addEventListener("click", function(event) {
            event.preventDefault();
            alert("Thank you for your interest!");
        });
    });

    const languageSelector = document.getElementById("language");
    const translations = {
        en: {
            "post-title": "Sample Blog Post",
            "post-author": "By John Doe - March 4, 2025",
            "post-content": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque sit amet venenatis urna.",
            "read-more": "Read More",
            "testimonials": "What Our Readers Say",
            "testimonial-1": "This blog has changed my perspective on so many things! Highly recommend it.",
            "testimonial-2": "Great content, well-structured, and always insightful!",
            "follow-us": "Follow Us",
            "contact-us": "Contact Us",
            "email": "Email: contact@myblog.com",
            "location": "Location: 123 Blog Street, City, Country",
            "get-in-touch": "Get in Touch",
            "footer": "&copy; 2025 My Blog. All rights reserved."
        },
        es: {
            "post-title": "Publicación de Blog",
            "post-author": "Por John Doe - 4 de marzo de 2025",
            "post-content": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque sit amet venenatis urna.",
            "read-more": "Leer Más",
            "testimonials": "Lo que dicen nuestros lectores",
            "testimonial-1": "¡Este blog cambió mi perspectiva sobre muchas cosas! Lo recomiendo mucho.",
            "testimonial-2": "Gran contenido, bien estructurado y siempre interesante.",
            "follow-us": "Síguenos",
            "contact-us": "Contáctanos",
            "email": "Correo: contact@myblog.com",
            "location": "Ubicación: 123 Blog Street, Ciudad, País",
            "get-in-touch": "Ponerse en contacto",
            "footer": "&copy; 2025 Mi Blog. Todos los derechos reservados."
        }
    };
    languageSelector.addEventListener("change", function() {
        const selectedLang = languageSelector.value;
        document.querySelectorAll("[data-lang]").forEach(element => {
            element.innerHTML = translations[selectedLang][element.getAttribute("data-lang")];
        });
    });
});
